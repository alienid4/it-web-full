# VMware + LDAP 離線部署包 v3.12.0.0

**目的**：為巡檢系統裝齊 VMware tab 所需的 Python SDK (`pyvmomi`) + LDAP/AD 查詢套件 (`python-ldap`)。
**適用**：RHEL 9 / Rocky 9 的巡檢系統主機 (Python 3.9)。
**總大小**：~2.5 MB。

## 內容

```
vmware_ldap_offline_v3.12.0.0/
├── wheels/
│   └── pyvmomi-9.0.0.0-py3-none-any.whl               (2.0 MB, 純 Python, pip --user)
├── rpms/
│   ├── python3-ldap-3.4.3-2.el9.x86_64.rpm            (215 KB, dnf localinstall)
│   ├── python3-pyasn1-0.4.8-6.el9.noarch.rpm          (132 KB, python3-ldap 依賴)
│   └── python3-pyasn1-modules-0.4.8-6.el9.noarch.rpm  (211 KB, python3-ldap 依賴)
├── install.sh                                          互動式安裝
├── verify.sh                                           獨立驗證
└── README.md                                           本檔
```

## 為什麼兩種格式

- **pyvmomi**：pure Python，universal wheel，無系統依賴 → 走 `pip --user`，裝到使用者 home，不動系統
- **python-ldap**：有 C 擴充 + 綁定 openldap 系統庫 → 用 Rocky 9 官方 RPM，走 `dnf localinstall`，不用現場編譯 (省去 gcc/openldap-devel 依賴鏈)

## 安裝

```bash
tar xzf vmware_ldap_offline_v3.12.0.0.tar.gz
cd vmware_ldap_offline_v3.12.0.0
chmod +x install.sh verify.sh
./install.sh        # 互動式 (需 sudo 安裝 RPM)
```

## 驗證

```bash
./verify.sh
```

預期輸出：
```
✅ pyvmomi 可用
   版本 : 9.0.0.0
✅ python-ldap 可用
   版本 : 3.4.3
✅ 全部套件可用
```

## 為什麼 pyasn1 也進來

`python3-ldap` RPM 硬依賴 `python3-pyasn1` / `python3-pyasn1-modules`，
若目標機器是純淨 Rocky 9，這兩個套件不一定裝了。
一起打包避免 `dnf localinstall` 時要求連外 repo。

若目標機已有 pyasn1 → dnf 自己會跳過，不會重覆裝。

## 與既有 `inspection_deps` 包的分工

| 包 | 內容 | 時機 |
|---|---|---|
| `inspection_deps_v3.5.0.0-testenv.tar.gz` | 系統基礎 + 既有巡檢所需 (Flask, Ansible, openldap-devel 等) | 第一次部署 |
| `vmware_ldap_offline_v3.12.0.0.tar.gz` (本包) | 僅 pyvmomi + python-ldap | 舊系統擴充 VMware tab |

## 移除 (如需)

```bash
# 移除 pyvmomi
python3 -m pip uninstall pyvmomi

# 移除 python-ldap
sudo dnf remove python3-ldap python3-pyasn1-modules python3-pyasn1
```

## 資安備註

- 本包**不含任何實際 IP / FQDN / 帳號 / 密碼**
- RPM 來源：Rocky Linux 官方鏡像 `dl.rockylinux.org/pub/rocky/9/AppStream`
- Wheel 來源：PyPI 官方 `pyvmomi` package
- 安裝過程會要求 sudo（RPM localinstall 必需）
