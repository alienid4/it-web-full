#!/bin/bash
# VMware tab + LDAP 離線部署包 v3.12.0.0
#   - pyvmomi 9.0.0.0 (Python wheel, pip --user)
#   - python3-ldap 3.4.3 + pyasn1 依賴 (Rocky 9 RPM, dnf localinstall)

set -e
cd "$(dirname "$0")"

WHITE='\033[1;37m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'

echo -e "${WHITE}========================================${NC}"
echo -e "${WHITE}VMware + LDAP 離線部署 v3.12.0.0${NC}"
echo -e "${WHITE}========================================${NC}"
echo "主機: $(hostname)"
echo "帳號: $(whoami)"
echo "Python: $(python3 --version 2>&1)"
echo "OS: $(cat /etc/redhat-release 2>/dev/null || cat /etc/os-release | grep PRETTY | cut -d= -f2)"
echo ""

need_sudo() {
    if [[ $EUID -ne 0 ]]; then
        echo -e "${YELLOW}⚠️  安裝 RPM 需要 sudo 權限，會提示輸入密碼${NC}"
        SUDO="sudo"
    else
        SUDO=""
    fi
}

# ============================================================
# Part 1: python3-ldap (RPM via dnf)
# ============================================================
echo -e "${WHITE}--- Part 1: python3-ldap (RPM) ---${NC}"

if python3 -c "import ldap" 2>/dev/null; then
    LDAP_VER=$(python3 -c "import ldap; print(ldap.__version__)" 2>/dev/null || echo "unknown")
    echo -e "${GREEN}✅ python-ldap 已安裝 (version: $LDAP_VER)，跳過${NC}"
else
    need_sudo
    echo "安裝 python3-ldap + pyasn1 依賴..."
    $SUDO dnf localinstall -y rpms/python3-pyasn1-*.noarch.rpm \
                              rpms/python3-pyasn1-modules-*.noarch.rpm \
                              rpms/python3-ldap-*.x86_64.rpm

    if python3 -c "import ldap; print('python-ldap version:', ldap.__version__)" 2>/dev/null; then
        echo -e "${GREEN}✅ python-ldap 安裝成功${NC}"
    else
        echo -e "${RED}❌ python-ldap 安裝失敗${NC}"
        exit 1
    fi
fi

echo ""

# ============================================================
# Part 2: pyvmomi (wheel via pip --user)
# ============================================================
echo -e "${WHITE}--- Part 2: pyvmomi (Python wheel) ---${NC}"

if python3 -c "import pyVmomi" 2>/dev/null; then
    PYV_VER=$(python3 -c "import pyVmomi; print(getattr(pyVmomi,'__version__','unknown'))" 2>/dev/null)
    echo -e "${YELLOW}⚠️  pyvmomi 已安裝 (version: $PYV_VER)${NC}"
    read -p "是否覆蓋重裝? [y/N] " ans
    if [[ "$ans" =~ ^[Yy]$ ]]; then
        python3 -m pip install --user --no-index --find-links=./wheels pyvmomi --force-reinstall
    else
        echo "跳過 pyvmomi"
    fi
else
    python3 -m pip install --user --no-index --find-links=./wheels pyvmomi
fi

if python3 -c "import pyVmomi, pyVim; print('pyvmomi version:', getattr(pyVmomi,'__version__','unknown'))" 2>/dev/null; then
    echo -e "${GREEN}✅ pyvmomi 可用${NC}"
else
    echo -e "${RED}❌ pyvmomi 安裝失敗${NC}"
    exit 1
fi

echo ""
echo -e "${WHITE}========================================${NC}"
echo -e "${GREEN}✅ 全部安裝完成${NC}"
echo -e "${WHITE}========================================${NC}"
echo ""
echo "下一步："
echo "  ./verify.sh                 # 整體驗證"
echo "  cd /opt/inspection ; git pull ; \\"
echo "  cat notes/2026-04-24/2026-04-24_1335_vcenter-connectivity-test.md   # 跑 VC 連通測試"
