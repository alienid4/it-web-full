#!/bin/bash
# 驗證 pyvmomi + python-ldap 是否可用

WHITE='\033[1;37m'; GREEN='\033[0;32m'; RED='\033[0;31m'; NC='\033[0m'

echo -e "${WHITE}VMware + LDAP 套件驗證${NC}"
echo "主機: $(hostname)"
echo "帳號: $(whoami)"
echo "Python: $(python3 --version 2>&1)"
echo "---"

RC=0

python3 <<'PYEOF' || RC=1
import sys
try:
    import pyVmomi, pyVim
    from pyVim.connect import SmartConnect, Disconnect
    from pyVmomi import vim
    print('\033[0;32m✅ pyvmomi 可用\033[0m')
    print('   版本 :', getattr(pyVmomi, '__version__', 'unknown'))
    print('   路徑 :', pyVmomi.__file__)
except ImportError as e:
    print('\033[0;31m❌ pyvmomi:', e, '\033[0m')
    sys.exit(1)
PYEOF

python3 <<'PYEOF' || RC=1
import sys
try:
    import ldap
    print('\033[0;32m✅ python-ldap 可用\033[0m')
    print('   版本 :', ldap.__version__)
    print('   路徑 :', ldap.__file__)
except ImportError as e:
    print('\033[0;31m❌ python-ldap:', e, '\033[0m')
    sys.exit(1)
PYEOF

if [ $RC -eq 0 ]; then
    echo ""
    echo -e "${GREEN}✅ 全部套件可用，可以開始跑 VMware tab 前置測試${NC}"
else
    echo ""
    echo -e "${RED}❌ 有套件問題，跑 ./install.sh 重裝${NC}"
    exit 1
fi
